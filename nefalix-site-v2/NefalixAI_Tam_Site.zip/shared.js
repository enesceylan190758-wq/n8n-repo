// Scroll reveal (JS yüklenince .pre eklenir, IntersectionObserver ile .in eklenir — JS yoksa içerik baştan görünür)
document.addEventListener('DOMContentLoaded', function() {
  const reveals = document.querySelectorAll('.reveal');
  reveals.forEach(el => el.classList.add('pre'));
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('in'); });
  }, { threshold: 0.12 });
  reveals.forEach(el => obs.observe(el));

  // Sayaç animasyonu (count-up) — JS yüklenince 0'dan başlar, JS yoksa zaten HTML'deki hedef değer görünür
  const counters = document.querySelectorAll('.stat-num[data-target]');
  counters.forEach(el => {
    const suffix = el.dataset.suffix || "";
    const isDecimal = el.dataset.target.includes(".");
    el.textContent = "0" + suffix;
  });
  const counterObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting && !e.target.dataset.done) {
        e.target.dataset.done = "1";
        const target = parseFloat(e.target.dataset.target);
        const suffix = e.target.dataset.suffix || "";
        const isDecimal = e.target.dataset.target.includes(".");
        let cur = 0;
        const step = target / 40;
        const tick = () => {
          cur += step;
          if (cur >= target) { e.target.textContent = (isDecimal ? target.toFixed(1) : target) + suffix; }
          else { e.target.textContent = (isDecimal ? cur.toFixed(1) : Math.floor(cur)) + suffix; requestAnimationFrame(tick); }
        };
        tick();
      }
    });
  }, { threshold: 0.3 });
  counters.forEach(el => counterObs.observe(el));

  // Sektör sekmeleri (Sektörler sayfası)
  document.querySelectorAll('.sector-tab').forEach(tab => {
    tab.addEventListener('click', function() {
      const group = this.closest('.sector-tabs').dataset.group;
      document.querySelectorAll(`.sector-tabs[data-group="${group}"] .sector-tab`).forEach(t => t.classList.remove('active'));
      this.classList.add('active');
      const target = this.dataset.target;
      document.querySelectorAll(`.sektor-panel[data-group="${group}"]`).forEach(p => p.style.display = 'none');
      const panel = document.querySelector(`.sektor-panel[data-group="${group}"][data-id="${target}"]`);
      if (panel) panel.style.display = 'block';
    });
  });

  // Rol sekmeleri (Kaynaklar sayfası önce-sonra tablosu)
  document.querySelectorAll('.role-tab').forEach(tab => {
    tab.addEventListener('click', function() {
      document.querySelectorAll('.role-tab').forEach(t => t.classList.remove('active'));
      this.classList.add('active');
      const target = this.dataset.target;
      document.querySelectorAll('.role-panel').forEach(p => p.style.display = 'none');
      const panel = document.querySelector(`.role-panel[data-id="${target}"]`);
      if (panel) panel.style.display = 'block';
    });
  });

  // Fiyatlandırma adım sayaçları (+/-)
  document.querySelectorAll('.counter-box').forEach(box => {
    const valEl = box.querySelector('.counter-val');
    box.querySelector('.counter-minus').addEventListener('click', () => {
      let v = parseInt(valEl.textContent);
      if (v > 1) valEl.textContent = v - 1;
    });
    box.querySelector('.counter-plus').addEventListener('click', () => {
      let v = parseInt(valEl.textContent);
      valEl.textContent = v + 1;
    });
  });

  // Modül checkbox toggle (Fiyatlandırma)
  document.querySelectorAll('.mcheck.premium').forEach(item => {
    item.addEventListener('click', function() {
      this.classList.toggle('checked');
      const cb = this.querySelector('.cb');
      cb.textContent = this.classList.contains('checked') ? '✓' : '';
    });
  });

  // FAQ accordion
  document.querySelectorAll('.faq-item h4').forEach(h => {
    h.addEventListener('click', function() {
      const p = this.nextElementSibling;
      const isOpen = p.style.display === 'block';
      p.style.display = isOpen ? 'none' : 'block';
      this.style.setProperty('--rot', isOpen ? '0deg' : '45deg');
    });
  });
});
